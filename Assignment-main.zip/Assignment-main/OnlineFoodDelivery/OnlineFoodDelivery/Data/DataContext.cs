using Microsoft.EntityFrameworkCore;
using OnlineFoodDelivery.Models;

namespace OnlineFoodDelivery.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        public DbSet<Hotels> HotelsList { get; set; }
        public DbSet<Menu> MenuItems { get; set; }
        public DbSet<Order> OrderItems { get; set; }

        // DO NOT MAKE ANY CHANGES IN THIS BELOW-MENTIONED METHOD
        // Please un-comment the below-given code before submitting/evaluating    
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Hotels>().HasKey(k => k.HotelId);
            modelBuilder.Entity<Menu>().HasKey(k => k.MenuId);
            modelBuilder.Entity<Order>().HasKey(k => k.Id);

            modelBuilder.Entity<Menu>()
                .HasOne(m => m.hotels)  // Ensure 'Hotels' is the correct navigation property in Menu class
                .WithMany(h => h.Menus) // Ensure 'Menus' is a collection in Hotels class
                .HasForeignKey(m => m.HotelId);

            modelBuilder.Entity<Order>()
                .HasOne(o => o.menu)   // Ensure 'Menu' is the correct navigation property in Order class
                .WithMany(m => m.Orders) // Ensure 'Orders' is a collection in Menu class
                .HasForeignKey(o => o.MenuId);

            modelBuilder.Entity<Menu>().Property(p => p.Price).HasPrecision(18, 4);
            modelBuilder.Entity<Order>().Property(p => p.Quantity).HasPrecision(18, 4);
        }
    }
}
