using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using OnlineFoodDelivery.Data;
using OnlineFoodDelivery.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

public class FoodDeliveryController : Controller
{
    private readonly DataContext _dataContext;
    public FoodDeliveryController(DataContext context)
    {
        _dataContext = context;
    }

    public IActionResult GetHotelList()
    {
        var hotels = _dataContext.HotelsList.ToList(); // Fetch all hotels
        return View(hotels); // Pass the list to the view
    }
    public IActionResult CreateHotel() => View();

    [HttpPost]
    public IActionResult CreateHotel(Hotels hotel)
    {
        if (ModelState.IsValid)
        {
            _dataContext.HotelsList.Add(hotel);
            _dataContext.SaveChanges();
            ViewBag.Message = "Hotel details Successfully Added";
            return View();
        }
        return View(hotel);
    }
    
    public IActionResult CreateMenu() => View();

    [HttpPost]
    public IActionResult CreateMenu(Menu menu)
    {
        if (ModelState.IsValid)
        {
            _dataContext.MenuItems.Add(menu);
            _dataContext.SaveChanges();
            ViewBag.Message = "Menu Items Successfully Added";
            return View();
        }
        return View(menu);
    }

    public IActionResult OrderPlacing() => View();

    [HttpPost]
    public IActionResult OrderPlacing(Order order)
    {
        if (ModelState.IsValid)
        {
            _dataContext.OrderItems.Add(order);
            _dataContext.SaveChanges();
            ViewBag.Message = "Order Successfully Placed";
            return View();
        }
        return View(order);
    }
    public IActionResult GetMenuList()
    {
        ViewBag.Menus = _dataContext.MenuItems.Include(m => m.hotels).ToList();
        return View();
    }
}
