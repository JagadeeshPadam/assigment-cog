using Microsoft.AspNetCore.Mvc;
using OnlineFoodDelivery.Data;
using OnlineFoodDelivery.Models;
using System.Linq;

namespace OnlineFoodDelivery.Controllers
{
    public class HomeController : Controller
    {
        private readonly DataContext _context;

        public HomeController(DataContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var hotels = _context.HotelsList.ToList();
            return View(hotels);
        }

        public IActionResult Menu(int hotelId)
        {
            var menuItems = _context.MenuItems.Where(m => m.HotelId == hotelId).ToList();
            return View(menuItems);
        }

        public IActionResult Order(int menuId)
        {
            var menuItem = _context.MenuItems.FirstOrDefault(m => m.MenuId == menuId);
            if (menuItem == null)
                return NotFound();

            return View(menuItem);
        }

        [HttpPost]
        public IActionResult PlaceOrder(int menuId, int quantity)
        {
            var menuItem = _context.MenuItems.FirstOrDefault(m => m.MenuId == menuId);
            if (menuItem == null)
                return NotFound();

            var order = new Order
            {
                MenuId = menuId,
                Quantity = quantity
            };

            _context.OrderItems.Add(order);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}
