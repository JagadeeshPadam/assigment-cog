﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineFoodDelivery.Models
{
    public class Menu
    {
        [Key]
        public int MenuId { get; set; }

        [Required(ErrorMessage = "Please enter the Menu Name")]
        public string NameOfMenu { get; set; }  // ✅ Ensure this exists

        [Required(ErrorMessage = "Please enter the Price")]
        public decimal Price { get; set; }

        [ForeignKey("Hotels")]
        public int HotelId { get; set; }
        public Hotels hotels { get; set; }

        public ICollection<Order> Orders { get; set; } = new List<Order>(); // ✅ Add this if missing
    }
}
