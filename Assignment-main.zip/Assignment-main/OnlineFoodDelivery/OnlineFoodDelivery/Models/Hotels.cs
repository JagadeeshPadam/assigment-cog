﻿using System.ComponentModel.DataAnnotations;

namespace OnlineFoodDelivery.Models
{
    public class Hotels
    {
        [Key]
        public int HotelId { get; set; }

        [Required(ErrorMessage = "Please enter the Hotel Name")]
        public string HotelName { get; set; }  // ✅ Ensure this exists

        [Required(ErrorMessage = "Please enter the City")]
        public string City { get; set; }  // ✅ Ensure this exists

        public ICollection<Menu> Menus { get; set; } = new List<Menu>(); // ✅ Add this if missing
    }
}
