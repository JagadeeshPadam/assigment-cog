using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineFoodDelivery.Models
{
    public class Order
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter the Quantity")]
        public int Quantity { get; set; }

        [ForeignKey("Menu")]
        public int MenuId { get; set; }
        public Menu? menu { get; set; }

        [NotMapped]
        public SelectList? MenuList { get; set; }
    }

}
